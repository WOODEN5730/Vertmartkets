﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Magazine
{
    public class Program
    {
        HttpClient client = new HttpClient();

        private static async Task Main(string[] args)
        {
            Console.WriteLine("Starting....");
            Program program = new Program();
            await program.GetApiData();

        }

        private async Task GetApiData()
        {
            string tokenUrl       = "http://magazinestore.azurewebsites.net/api/token";
            string subscriberUrl  = "http://magazinestore.azurewebsites.net/api/subscribers/";
            string categoriesUrl  = "http://magazinestore.azurewebsites.net/api/categories/";
            string magazinesUrl   = "http://magazinestore.azurewebsites.net/api/magazines/";
            //string answerUrl    = "http://magazinestore.azurewebsites.net/api/answer/";
           
            SortedDictionary<int, string> magazine = new SortedDictionary<int, string>();
            List<Subscription> subcriptions = new List<Subscription>();
            
            // Get Token
            string response = await client.GetStringAsync(tokenUrl);
            Token todo = JsonConvert.DeserializeObject<Token>(response);
            Console.WriteLine(" Token:{0}",todo.token);
                        
            Console.WriteLine("Categories");
            response = await client.GetStringAsync(categoriesUrl + todo.token);
            Category root2 = JsonConvert.DeserializeObject<Category>(response);
            var category = root2.data;

            foreach (var rd1 in category)
            {
                Console.WriteLine("{0}", rd1);
            }
            foreach (var rd1 in category)
                {
                //Get Magazines
                response = await client.GetStringAsync(magazinesUrl + todo.token + "/" + rd1);
                RootMagazine rootmagazine = JsonConvert.DeserializeObject<RootMagazine>(response);
                var magazines = rootmagazine.data;
                foreach (var rmag in magazines)
                {
                    magazine.Add(rmag.id, rmag.category);
                }
            }                           

            //Get Subscriber 
            Console.WriteLine("Subscriber with Categories");
             response = await client.GetStringAsync(subscriberUrl + todo.token);            
             var root = JsonConvert.DeserializeObject<RootSubscribers>(response);
             var series = root.data;
            foreach (var rd in series)
            {
                for (int i = 0; i < rd.magazineIds.Count; i++)
                {
                    string value = "";
                    var test = magazine.ContainsKey(rd.magazineIds[i]);
                    if (test == true)
                    {
                        magazine.TryGetValue(rd.magazineIds[i], out value);
                        Console.WriteLine("{0} {1}", rd.id, value);

                        var subcriptions1 = new Subscription
                        {
                            id = rd.id,
                            category = value
                        };
                        subcriptions.Add(subcriptions1);
                    }
                }
            }
            foreach(var id in category)
            {
                Console.WriteLine("{0}", id);
            }

            var distinctGroupIds = subcriptions.GroupBy(x => x.id);
            var dd = distinctGroupIds.Distinct();
            foreach (var dg in dd)
            {
                Console.WriteLine("{0} {1}", dg.Key, dg.Count());
            }

            Console.ReadKey();


        }
    }            
            // ToDO
            //Console.WriteLine("Answer");
            //response = await client.GetStringAsync(answerUrl + todo.token);
            //Console.WriteLine(response);

            //RootAnswer rootanswer = JsonConvert.DeserializeObject<RootAnswer>(response);
            //var series3 = rootanswer.answerCorrect;
            //Console.WriteLine("{0}", series3);

            
   }
    