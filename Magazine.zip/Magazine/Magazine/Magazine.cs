﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Magazine
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class Magazine
    {
        public int id { get; set; }
        public string name { get; set; }
        public string category { get; set; }
    }

    public class RootMagazine
    {
        public List<Magazine> data { get; set; }
        public bool success { get; set; }
        public string token { get; set; }
        public string message { get; set; }
    }


}
