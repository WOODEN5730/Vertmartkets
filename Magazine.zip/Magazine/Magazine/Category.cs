﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Magazine
{
    // Category myDeserializedClass = JsonConvert.DeserializeObject<Category>(myJsonResponse); 
    public class Category
    {
        public List<string> data { get; set; }
        public bool success { get; set; }
        public string token { get; set; }
        public string message { get; set; }
    }

}
