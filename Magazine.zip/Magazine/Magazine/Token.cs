﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Magazine
{
    public class Token
    {
        public string success { get; set; }
        public string token { get; set; }
    }  
}
