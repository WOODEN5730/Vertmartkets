﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Magazine
{
    // RootAnswer myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class Answer
    {
        public string totalTime { get; set; }
        public bool answerCorrect { get; set; }
        public List<string> shouldBe { get; set; }
    }

    public class RootAnswer
    {
        public Answer data { get; set; }
        public bool success { get; set; }
        public string token { get; set; }
        public string message { get; set; }
    }


}
