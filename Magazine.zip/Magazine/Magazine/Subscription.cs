﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Magazine
{
    public class Subscription
    {
        public string id { get; set; }
        public string category { get; set; }
    }
}
